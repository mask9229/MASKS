# MASKS Browser — Android starter project

Первая исходная версия MASKS для Android: браузер на Android System WebView (Chromium engine), адресная строка/поиск, назад/вперёд/обновить, вкладки, загрузки и тёмный фиолетовый интерфейс.

## Сборка APK

1. Установите Android Studio (актуальную стабильную версию) и Android SDK Platform 35.
2. Откройте папку `MASKS-Android` в Android Studio.
3. Дождитесь Gradle Sync.
4. Выберите **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Для терминальной сборки на машине с установленным Android SDK и Gradle:

```bash
gradle assembleDebug
```

## Текущий объём версии 0.1.0

- Открытие HTTP/HTTPS сайтов через Android WebView (системный Chromium WebView).
- Поиск через DuckDuckGo, если введён поисковый запрос.
- Переключение и закрытие вкладок.
- История навигации внутри вкладки.
- Загрузка файлов через Android DownloadManager.
- Базовая тёмная тема MASKS.

## Пока не реализовано

- Визуальный конструктор MASKS Studio.
- Закладки и постоянная история.
- Режим инкогнито/профили.
- Синхронизация с Windows.
- Полноценный менеджер разрешений и расширенные настройки приватности.

## Примечание по движку

На Android приложение использует Android System WebView — компонент на базе Chromium, который обновляется через систему/Google Play. Это не отдельная поставка полного настольного Chromium.
