package com.masks.browser

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 7, 13)
    private val panel = Color.rgb(21, 16, 29)
    private val purple = Color.rgb(139, 69, 255)
    private val text = Color.WHITE
    private val muted = Color.rgb(166, 154, 175)

    private lateinit var root: LinearLayout
    private lateinit var tabsBar: LinearLayout
    private lateinit var address: EditText
    private lateinit var pageHost: LinearLayout
    private val pages = mutableListOf<WebView>()
    private var active = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        addTab("https://duckduckgo.com")
    }

    private fun buildUi() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val brand = TextView(this).apply {
            text = "◈  MASKS"; setTextColor(purple); textSize = 20f; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(9), dp(12), dp(5)); typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(42)))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(8), dp(5)); setBackgroundColor(panel)
        }
        nav.addView(action("‹") { current()?.let { if (it.canGoBack()) it.goBack() } }, LinearLayout.LayoutParams(dp(40), dp(42)))
        nav.addView(action("›") { current()?.let { if (it.canGoForward()) it.goForward() } }, LinearLayout.LayoutParams(dp(40), dp(42)))
        nav.addView(action("↻") { current()?.reload() }, LinearLayout.LayoutParams(dp(40), dp(42)))
        address = EditText(this).apply {
            setSingleLine(true); textSize = 14f; setTextColor(text); setHintTextColor(muted)
            hint = "Введите адрес или поисковый запрос"; setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(35, 25, 47)); imeOptions = EditorInfo.IME_ACTION_GO
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                    loadAddress(this.text.toString()); hideKeyboard(); true
                } else false
            }
        }
        nav.addView(address, LinearLayout.LayoutParams(0, dp(42), 1f))
        nav.addView(action("＋") { addTab("https://duckduckgo.com") }, LinearLayout.LayoutParams(dp(44), dp(42)))
        root.addView(nav)

        tabsBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(6), dp(4), dp(6), dp(4)); setBackgroundColor(bg) }
        root.addView(tabsBar, LinearLayout.LayoutParams(-1, dp(42)))

        pageHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        root.addView(pageHost, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setBackgroundColor(panel); setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        bottom.addView(bottomAction("⌂", "Домой") { current()?.loadUrl("https://duckduckgo.com"); updateAddress() }, weightParams())
        bottom.addView(bottomAction("☆", "Закладка") { Toast.makeText(this, "Закладки добавим в следующей версии", Toast.LENGTH_SHORT).show() }, weightParams())
        bottom.addView(bottomAction("▣", "Вкладки") { renderTabs() }, weightParams())
        bottom.addView(bottomAction("⋮", "Меню") { showMenu() }, weightParams())
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(54)))
        setContentView(root)
    }

    private fun action(label: String, click: () -> Unit) = TextView(this).apply {
        text = label; textSize = 25f; gravity = Gravity.CENTER; setTextColor(text); setOnClickListener { click() }
    }

    private fun bottomAction(symbol: String, label: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        addView(TextView(this@MainActivity).apply { text = symbol; textSize = 21f; gravity = Gravity.CENTER; setTextColor(purple) })
        addView(TextView(this@MainActivity).apply { text = label; textSize = 10f; gravity = Gravity.CENTER; setTextColor(muted) })
        setOnClickListener { click() }
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, dp(46), 1f)

    private fun createWebView(): WebView = WebView(this).apply {
        setBackgroundColor(Color.WHITE)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.setSupportMultipleWindows(false)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            settings.safeBrowsingEnabled = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase()
                return scheme != "http" && scheme != "https"
            }
            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                if (pages.getOrNull(active) === view && url != null) address.setText(url)
            }
            override fun onPageFinished(view: WebView, url: String?) {
                if (pages.getOrNull(active) === view && url != null) address.setText(url)
                renderTabs()
            }
        }
        setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    .setTitle(android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType))
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                        android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType))
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this@MainActivity, "Загрузка началась", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) { Toast.makeText(this@MainActivity, "Не удалось начать загрузку", Toast.LENGTH_SHORT).show() }
        })
    }

    private fun addTab(url: String) {
        val web = createWebView()
        pages.add(web)
        active = pages.lastIndex
        pageHost.removeAllViews()
        pageHost.addView(web, ViewGroup.LayoutParams(-1, -1))
        web.loadUrl(url)
        updateAddress()
        renderTabs()
    }

    private fun switchTab(index: Int) {
        if (index !in pages.indices) return
        active = index
        pageHost.removeAllViews()
        pageHost.addView(pages[index], ViewGroup.LayoutParams(-1, -1))
        updateAddress(); renderTabs()
    }

    private fun closeTab(index: Int) {
        if (pages.size <= 1) { pages[index].loadUrl("https://duckduckgo.com"); return }
        val removed = pages.removeAt(index)
        pageHost.removeView(removed); removed.destroy()
        active = (index.coerceAtMost(pages.lastIndex)).coerceAtLeast(0)
        switchTab(active)
    }

    private fun renderTabs() {
        if (!::tabsBar.isInitialized) return
        tabsBar.removeAllViews()
        pages.forEachIndexed { index, web ->
            val title = web.title?.take(12)?.ifBlank { "Вкладка ${index + 1}" } ?: "Вкладка ${index + 1}"
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                setPadding(dp(9), 0, dp(5), 0); setBackgroundColor(if (index == active) Color.rgb(48, 29, 68) else panel)
            }
            chip.addView(TextView(this).apply { text = title; textSize = 11f; setTextColor(text); maxLines = 1 })
            chip.addView(TextView(this).apply { text = " × "; textSize = 14f; setTextColor(muted); setOnClickListener { closeTab(index) } })
            chip.setOnClickListener { switchTab(index) }
            tabsBar.addView(chip, LinearLayout.LayoutParams(0, dp(32), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
    }

    private fun loadAddress(raw: String) {
        val value = raw.trim()
        if (value.isEmpty()) return
        val url = when {
            value.startsWith("https://") || value.startsWith("http://") -> value
            value.contains(" ") || !value.contains(".") -> "https://duckduckgo.com/?q=" + Uri.encode(value)
            else -> "https://$value"
        }
        current()?.loadUrl(url)
    }

    private fun updateAddress() { address.setText(current()?.url ?: "") }
    private fun current() = pages.getOrNull(active)
    private fun hideKeyboard() { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(address.windowToken, 0); address.clearFocus() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showMenu() {
        val items = arrayOf("Новая вкладка", "Обновить страницу", "Открыть MASKS Studio (скоро)", "О браузере MASKS")
        android.app.AlertDialog.Builder(this).setTitle("MASKS").setItems(items) { _, which ->
            when (which) {
                0 -> addTab("https://duckduckgo.com")
                1 -> current()?.reload()
                2 -> Toast.makeText(this, "Визуальный конструктор появится в следующем этапе", Toast.LENGTH_LONG).show()
                3 -> android.app.AlertDialog.Builder(this).setTitle("MASKS Browser").setMessage("Версия 0.1.0\nБраузер на Android WebView (Chromium).\nСоздан в рамках проекта MASKS.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    override fun onBackPressed() {
        val web = current()
        if (web?.canGoBack() == true) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        pages.forEach { it.stopLoading(); it.destroy() }
        pages.clear()
        super.onDestroy()
    }
}
